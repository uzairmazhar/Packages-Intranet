<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'HomeController@index');

Route::get('history', 'Packages@history');
Route::get('company-information', 'Packages@companyInformation');
Route::get('global-partner','Packages@globalPartner');
Route::get('policies','Packages@policies');
route::get('about-us','Packages@aboutUs');
Route::get('company-information','Packages@companyInformation');

Route::get('materials-management','SAP@materialsManagement');
Route::get('sales-and-distribution','SAP@salesAndDistribution');
Route::get('production-planning','SAP@productionPlanning');
Route::get('controlling','SAP@controlling');
Route::get('human-resource','SAP@humanResources');
Route::get('human-capital-management','SAP@humanCapitalManagement');
Route::get('finance-accounting','SAP@financeAccounting');
Route::get('plant-maintenance','SAP@plantMaintenance');

Route::get('annual-reports','Reports@annualReports');
Route::get('quarterly-reports','Reports@quarterlyReports');

Route::get('qa&ehs','QAEHSController@qaEhs');

Route::get('rd-introduction','RAndD@rdIntroduction');
Route::get('rd-high-yield-pulp','RAndD@rdHighYieldPulp');
Route::get('rd-continues-digestor','RAndD@rdContinuesDigestor');
Route::get('rd-liquid-packing','RAndD@rdLiquidPacking');

Route::get('all-policies','Allpolicies@policies');

Route::get('home', 'HomeController@index');
Route::get('timeline-see-more','HomeController@timelineSeeMore');
Route::get('event','HomeController@Event');
Route::get('event-submit-form','forms@eventForm');

Route::get('pic-video','HomeController@pivVideo');
//Route::get('pic-video/#away-day','HomeController@pivVideo(id)');

