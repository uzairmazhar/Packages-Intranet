<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class SAP extends Controller {

	public function materialsManagement()
    {
        return view('pages.sap.materials-management');
    }

    public function salesAndDistribution()
    {
        return view('pages.sap.sales-and-distribution');
    }
    public  function plantMaintenance()
    {
        return view('pages.sap.plant-maintenance');
    }
    public function productionPlanning()
    {
        return view('pages.sap.production-planning');
    }
    public function controlling()
    {
        return view('pages.sap.controlling');
    }
    public function humanResources()
    {
        return view('pages.sap.human-resource');
    }

    public function financeAccounting()
    {
        return view('pages.sap.finance-accounting');
    }
    public function humanCapitalManagement()
    {
        return view('pages.sap.human-capital-management');
    }
}
