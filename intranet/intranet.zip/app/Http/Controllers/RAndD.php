<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class RAndD extends Controller {

	public function rdIntroduction()
    {
        return view('pages.r&d.rd-introduction');
    }
    public function rdContinuesDigestor()
    {
        return view('pages.r&d.rd-continues-digestor');
    }
    public function rdHighYieldPulp()
    {
        return view('pages.r&d.rd-high-yield-pulp');
    }
    public function rdLiquidPacking()
    {
        return view('pages.r&d.rd-liquid-packing');
    }

}
