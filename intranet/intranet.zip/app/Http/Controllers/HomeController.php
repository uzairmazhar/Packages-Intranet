<?php namespace App\Http\Controllers;

class HomeController extends Controller {

	public function index()
	{
		return view('pages.home');
	}
	public function timelineSeeMore()
	{
		return view('pages.timeline-see-more');
	}
	public function Event()
	{
		return view('pages.event');
	}
	public function pivVideo()
	{
		return view('pages.pic-video');
	}

}
