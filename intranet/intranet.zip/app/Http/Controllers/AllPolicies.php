<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class AllPolicies extends Controller {

	public function policies()
    {
        return view('pages.all-policies.all-policies');
    }

}
