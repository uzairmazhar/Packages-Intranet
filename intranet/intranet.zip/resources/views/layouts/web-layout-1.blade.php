<!DOCTYPE html>
<html lang="en-US">

<head>
    <title>Intranet Portal</title>
    <link rel="shortcut icon" type="image/x-icon" href="{{asset('assets/img/p.png')}}">
    <meta name="author" content="Nile-Theme">
    <meta name="robots" content="index follow">
    <meta name="googlebot" content="index follow">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="keywords" content="Travel, HTML5, CSS3, Hotel , Multipurpose, Template, Create a Travel website fast">
    <meta name="description" content="HTML5 Multipurpose Template, Create a website fast">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- google fonts -->
    <link href="{{asset('https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,400,700,400i,500%7CDosis:300')}}"
          rel="stylesheet">
    <!-- animate -->
    <link rel="stylesheet" href="{{asset('assets/css/animate.css')}}"/>
    <!-- owl Carousel assets -->
    <link href="{{asset('assets/css/owl.carousel.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/owl.theme.css')}}}" rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- hover anmation -->
    <link rel="stylesheet" href="{{asset('assets/css/hover-min.css')}}">
    <!-- flag icon -->
    <link rel="stylesheet" href="{{asset('assets/css/flag-icon.min.css')}}">
    <!-- main style -->
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    <!-- colors -->
    <link rel="stylesheet" href="{{asset('assets/css/colors/main.css')}}">
    <!-- elegant icon -->
    <link rel="stylesheet" href="{{asset('assets/css/elegant_icon.css')}}">

    <!-- jquery library  -->
    <script type="text/javascript" src="{{asset('assets/js/jquery-3.2.1.min.js')}}"></script>
    <!-- fontawesome  -->
    <script defer src="{{asset('https://use.fontawesome.com/releases/v5.0.6/js/all.js')}}"></script>
    <!-- google maps api  -->
    <script type="text/javascript" src="{{asset('http://maps.google.com/maps/api/js?sensor=false')}}"></script>
    <script type="text/javascript" src="{{asset('assets/js/jquery.gomap-1.3.3.min.js')}}"></script>

    <!-- REVOLUTION STYLE SHEETS -->
    <link rel="stylesheet" type="text/css"
          href="{{asset('assets/revslider/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/revslider/fonts/font-awesome/css/font-awesome.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/revslider/css/settings.css')}}">
    <!-- REVOLUTION LAYERS STYLES -->

    <!-- REVOLUTION JS FILES -->
    <script type="text/javascript" src="{{asset('assets/revslider/js/jquery.themepunch.tools.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets/revslider/js/jquery.themepunch.revolution.min.js')}}"></script>

    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.actions.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.carousel.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.kenburn.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.layeranimation.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.migration.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.navigation.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.parallax.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.slideanims.min.js')}}"></script>
    <script type="text/javascript"
            src="{{asset('assets/revslider/js/extensions/revolution.extension.video.min.js')}}"></script>

</head>


<!-- ======= Header  ======= -->
<header class="background-white">
    <div class="header-output">
        <div class="container header-in">
            <div class="row">
                <div class="col-lg-2">
                    <a id="logo" href="{{URL::to('home')}}" style="margin: 0;"
                       class="d-inline-block margin-tb-10px"><img src="{{asset('assets/img/p.png')}}"
                                                                  style="height: 70px;" alt="packages-blue-logo"></a>
                    <a class="mobile-toggle padding-15px background-main-color" href="#"><i class="fas fa-bars"></i></a>
                </div>
                <div class="col-lg-8 position-inherit">
                    <ul id="menu-main" class="float-lg-left nav-menu link-padding-tb-25px">
                        <li class="has-dropdown"><a href="#">Packages</a>

                            <ul class="sub-menu">
                                <style> li .has-dropdown a::after {
                                        content: " " !important;
                                    }</style>
                                <li class="has-dropdown"><a href="{{URL::to('about-us')}}">About Packages</a>
                                </li>
                                <li class="has-dropdown"><a href="{{URL::to('history')}}">History</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('company-information')}}">Company
                                        Information</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('policies')}}">Policies</a></li>
                                <li class="has-dropdown"><a href="{{asset('#')}}">The Story Of
                                        Packages</a></li>

                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="#">Reports</a>

                            <ul class="sub-menu">
                                <style> li .has-dropdown a::after {
                                        content: " " !important;
                                    }</style>
                                <li class="has-dropdown"><a href="{{URL::to('annual-reports')}}">Annual Report</a>
                                </li>
                                <li class="has-dropdown"><a href="{{URL::to('quarterly-reports')}}"> Quarterly
                                        Report</a></li>

                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="#">Sap</a>
                            <ul class="sub-menu">
                                <style> li .has-dropdown a::after {
                                        content: " " !important;
                                    }</style>
                                <li class="has-dropdown"><a href="{{URL::to('materials-management')}}">Materials
                                        Management</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('sales-and-distribution')}}">Sales and
                                        Distribution</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('production-planning')}}">Production
                                        Planning</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('plant-maintenance')}}">Plant
                                        Maintenance</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('controlling')}}">Controlling</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('human-resource')}}">Human Resource</a>
                                </li>
                                <li class="has-dropdown"><a href="{{URL::to('human-capital-management')}}">Human
                                        Capital Management</a></li>
                                <li class="has-dropdown"><a href="{{URL::to('finance-accounting')}}">Finance
                                        Accounting</a></li>

                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="#">EHS</a>
                            <ul class="sub-menu">
                                <style> li .has-dropdown a::after {
                                        content: " " !important;
                                    }</style>
                                <li class="has-dropdown"><a href="{{URL::to('qa&ehs')}}">QA&EHS
                                    </a></li>
                                <li class="has-dropdown"><a
                                            href="{{URL::to('http://172.16.1.44/green_office/index.html')}}">Green
                                        Office
                                    </a></li>
                            </ul>
                        </li>
                        <li class=""><a href="{{URL::to('#')}}">Library</a></li>
                        <li class="has-dropdown"><a href="#">R & D</a>
                            <ul class="sub-menu">
                                <style> li .has-dropdown a::after {
                                        content: " " !important;
                                    }</style>
                                <li class="has-dropdown"><a href="{{URL::to('rd-introduction')}}">Introduction
                                    </a></li>
                                <li class="has-dropdown"><a href="{{URL::to('rd-high-yield-pulp')}}">High Yield Pulp
                                    </a></li>
                                <li class="has-dropdown"><a href="{{URL::to('rd-continues-digestor')}}">Continuous
                                        Digestor
                                    </a></li>
                                <li class="has-dropdown"><a href="{{URL::to('rd-liquid-packing')}}">Liquid
                                        Packaging</a></li>
                            </ul>
                        </li>
                        <li class=""><a href="{{URL::to('all-policies')}}">Policies</a></li>
                        <li class="has-dropdown"><a href="#">Forms</a>
                            <ul class="sub-menu">
                                <style> li .has-dropdown a::after {
                                        content: " " !important;
                                    }</style>
                                <li class="has-dropdown"><a
                                            href="{{asset('assets/docs/Forms/Materials Disposal Form.pdf')}}">Materials
                                        Disposal Form </a></li>
                                <li class="has-dropdown"><a
                                            href="{{asset('assets/docs/Forms/Amended Vacancy Approval Form.pdf')}}">
                                        Amended Vacancy Approval Form</a>
                                </li>
                                <li class="has-dropdown"><a
                                            href="{{asset('assets/docs/Forms/Asset Transfer Form.pdf')}}">Asset Transfer
                                        Form </a></li>
                                <li class="has-dropdown"><a
                                            href="{{asset('assets/docs/Forms/Capital Expenditure Form.pdf')}}"> Capital
                                        Expenditure Form</a></li>
                                <li class="has-dropdown"><a href="{{asset('assets/docs/Forms/In Patient Form.pdf')}}">
                                        In Patient form</a></li>
                                <li class="has-dropdown"><a
                                            href="{{asset('assets/docs/Forms/Medical Claim Form.pdf')}}"> Medical Claim
                                        Form</a></li>
                                <li class="has-dropdown"><a href="{{asset('assets/docs/Forms/Misc Cash Voucher.pdf')}}">
                                        Miscellaneous Cash Voucher</a>
                                </li>
                                <li class="has-dropdown"><a
                                            href="{{asset('assets/docs/Forms/Providend fund load form.pdf')}}">
                                        Provident Fund Loan Form</a></li>
                                <li class="has-dropdown"><a
                                            href="{{asset('assets/docs/Forms/Assets Disposal Form.pdf')}}">Assets
                                        Disposal Form </a></li>
                            </ul>
                        </li>
                    </ul>
                    <div class="d-none d-lg-block search-link pull-left float-lg-left model-link margin-top-15px">
                        <a id="search-header" class="model-link margin-left-20px opacity-hover-5" href="#">
                            <svg class="svg-inline--fa fa-search fa-w-16 float-lg-right" aria-hidden="true" data-prefix="fa"
                                 data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                 data-fa-i2svg="">
                                <path fill="currentColor"
                                      d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                            </svg><!-- <i class="fa fa-search"></i> -->
                        </a>
                    </div>
                </div>
                <div class="col-lg-2" >
                    <div class="col-lg-12" style="margin: 0;padding: 0; text-align: center;">
                        <a href="{{URL::to('#')}}" style="margin: 0;text-align: center;"
                           class="d-inline-block margin-tb-10px "><img src="{{asset('assets/img/p.png')}}"
                                                                       style="height: 50px;" alt="Our-Values"></a>
                    </div>
                    <div class="col-lg-12" style="margin: 0;padding: 0; text-align: center">
                        <p style="font-size: 14px;color:gray; margin: 0">Creating a better tomorrow</p>
                    </div>


                </div>
            </div>
        </div>
    </div>
</header>
<!-- ======= end Header  ======= -->

@yield('body')

<div class="padding-tb-50px background-main-color wow fadeInUp" style="">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="text-white margin-tb-15px text-center text-lg-left">
                    Packages | @2018 All copy rights reserved
                </div>
            </div>
            <div class="col-md-2">
                <div class="text-center">
                    <img src="{{asset('assets/img/pWhite.png')}}" style="height: 70px" alt="packages-white-logo">
                </div>
            </div>
            <div class="col-md-5">
                <ul class="list-inline text-lg-right text-center margin-lr-0px margin-tb-15px text-white">
                    <li class="list-inline-item margin-lr-8px"><a class="facebook" target="_blank"
                                                                  href="{{URL::to('https://www.facebook.com/PackagesLimited/')}}"><i
                                    class="fab fa-facebook-f"></i></a></li>
                    <li class="list-inline-item margin-lr-8px"><a class="facebook" target="_blank" href="#"><i
                                    class="fab fa-youtube"></i></a></li>
                    <li class="list-inline-item margin-lr-8px"><a class="facebook" target="_blank"
                                                                  href="{{URL::to('https://www.linkedin.com/in/packages-limited-570a03132/')}}"><i
                                    class="fab fa-linkedin"></i></a></li>
                    <li class="list-inline-item margin-lr-8px"><a class="facebook" target="_blank" href="#"><i
                                    class="fab fa-google-plus"></i></a></li>
                    <li class="list-inline-item margin-lr-8px"><a class="facebook" target="_blank" href="#"><i
                                    class="fab fa-twitter"></i></a></li>
                    <li class="list-inline-item margin-lr-8px"><a class="rss" target="_blank" href="#"><i
                                    class="fa fa-rss"
                                    aria-hidden="true"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="{{asset('assets/js/sticky-sidebar.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/YouTubePopUp.jquery.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/owl.carousel.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/imagesloaded.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/wow.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/custom.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/popper.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/bootstrap.min.js')}}"></script>
</body>

</html>