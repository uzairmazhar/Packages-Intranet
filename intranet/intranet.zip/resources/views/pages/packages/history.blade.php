@extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <section class="background-grey-1 padding-tb-25px text-grey-4">
        <div class="container">
            <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px">
                <h3>Packages History</h3>
            </h6>
            <div class="clearfix">
            </div>
        </div>
    </section>
    <div class="padding-tb-40px background-light-grey" style="transform: none;">
        <div class="container" style="transform: none;">

            <div class="row" style="transform: none;">
                <!--  content -->

                <div class="col-lg-12 col-md-10 sticky-content"
                     style="position: relative; overflow: visible; box-sizing: border-box; min-height: 870px;">
                    <section class=" padding-tb-25px text-grey-4">
                        <div class="container">
                            <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
                                <ul class="pagination pagination-md pagination-style-2 color ">

                                    <li><a class="page-link wow fadeInUp" href="#1956">1956</a></li>
                                    <li><a class="page-link wow fadeInDown" href="#1965">1965</a></li>
                                    <li><a class="page-link wow fadeInUp" href="#1968">1968</a></li>
                                    <li><a class="page-link wow fadeInDown" href="#1970">1970</a></li>
                                    <li><a class="page-link wow fadeInUp" href="#1982">1982</a></li>

                                    <li><a class="page-link wow fadeInUp" href="#1986">1986</a></li>
                                    <li><a class="page-link wow fadeInDown" href="#1993">19993</a></li>
                                    <li><a class="page-link wow fadeInUp" href="#1994">1994</a></li>
                                    <li><a class="page-link wow fadeInDown" href="#1996">1996</a></li>
                                    <li><a class="page-link wow fadeInUp" href="#1999">1999-2002</a></li>


                                </ul>
                            </ol>
                            <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
                                <ul class="pagination pagination-md pagination-style-2 color ">


                                    <li><a class="page-link wow fadeInUp" href="#2005">2005</a></li>
                                    <li><a class="page-link wow fadeInDown" href="#2011">2011</a></li>
                                    <li><a class="page-link wow fadeInUp" href="#2012">2012</a></li>
                                    <li><a class="page-link wow fadeInDown" href="#2014">2014</a></li>
                                    <li><a class="page-link wow fadeInUp" href="#2015">2015</a></li>
                                    <li><a class="page-link wow fadeInUp" href="#2017">2017</a></li>

                                </ul>
                            </ol>

                            <div class="clearfix">

                            </div>
                        </div>
                    </section>
                    <div id="1956"
                         class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px wow fadeInRight">
                        <ul class="row no-gutters padding-0px margin-0px list-unstyled">
                            <li class="col-lg-12 col-md-6 with-hover">
                                <img src="{{asset('assets/img/intranet/HISTORY/History/Picture2.jpg')}}" alt="">
                                <a href="{{URL::to('assets/img/intranet/HISTORY/History/Picture2.jpg')}}"
                                   data-toggle="lightbox"
                                   data-gallery="example-gallery"
                                   class="d-block hover-option  img-fluid">
                                    <div class="text-center text-white padding-top-n-20">
                                        <h1 style="font-size: 75px;">1956</h1><br>
                                        <p style="font-size: 20px;">A JOINT VENTURE BETWEEN PAPER AND PAPERBOARD
                                            CREATED CONSUMER PACKAGING.
                                        </p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                     <!--  <div class="padding-30px">
                            <div class="post-entry">
                                <div class="d-block text-up-small text-grey-4 margin-bottom-15px wow fadeInLeft">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority
                                        have
                                        suffered alteration in some form, by injected humour, or randomised words which
                                        don't look
                                        even slightly believable. If you are going to use a passage of Lorem Ipsum, you
                                        need
                                        to be
                                        sure there isn't anything embarrassing hidden in the middle of text. All the
                                        Lorem
                                        Ipsum
                                        generators on the Internet tend to repeat predefined chunks as necessary, making
                                        this the
                                        first true generator on the Internet. It uses a dictionary of over 200 Latin
                                        words,
                                        combined
                                        with a handful of model sentence structures, to generate Lorem Ipsum which looks
                                        reasonable.
                                        The generated Lorem Ipsum is therefore always free from repetition, injected
                                        humour,
                                        or
                                        non-characteristic words etc.
                                    </p>

                                </div>
                            </div>
                        </div>-->
                    </div>
                    <div id="1965"
                         class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px wow fadeInRight">
                        <ul class="row no-gutters padding-0px margin-0px list-unstyled">
                            <li class="col-lg-12 col-md-6 with-hover">
                                <img src="{{asset('assets/img/intranet/HISTORY/History/Picture3.jpg')}}" alt="">
                                <a href="{{URL::to('assets/img/intranet/HISTORY/History/Picture3.jpg')}}"
                                   data-toggle="lightbox"
                                   data-gallery="example-gallery"
                                   class="d-block hover-option  img-fluid">
                                    <div class="text-center text-white padding-top-n-20">
                                        <h1 style="font-size: 75px;">1965</h1><br>
                                        <p style="font-size: 20px;">PACKAGES LIMITED WENT PUBLIC.

                                        </p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                     <!--   <div class="padding-30px">
                            <div class="post-entry">
                                <div class="d-block text-up-small text-grey-4 margin-bottom-15px wow fadeInLeft">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority
                                        have
                                        suffered alteration in some form, by injected humour, or randomised words which
                                        don't look
                                        even slightly believable. If you are going to use a passage of Lorem Ipsum, you
                                        need
                                        to be
                                        sure there isn't anything embarrassing hidden in the middle of text. All the
                                        Lorem
                                        Ipsum
                                        generators on the Internet tend to repeat predefined chunks as necessary, making
                                        this the
                                        first true generator on the Internet. It uses a dictionary of over 200 Latin
                                        words,
                                        combined
                                        with a handful of model sentence structures, to generate Lorem Ipsum which looks
                                        reasonable.
                                        The generated Lorem Ipsum is therefore always free from repetition, injected
                                        humour,
                                        or
                                        non-characteristic words etc.
                                    </p>

                                </div>
                            </div>
                        </div>-->
                    </div>
                    <div id="1968"
                         class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px wow fadeInRight">
                        <ul class="row no-gutters padding-0px margin-0px list-unstyled">
                            <li class="col-lg-12 col-md-6 with-hover">
                                <img src="{{asset('assets/img/intranet/HISTORY/History/Picture4.png')}}" alt="">
                                <a href="{{URL::to('assets/img/intranet/HISTORY/History/Picture4.png')}}"
                                   data-toggle="lightbox"
                                   data-gallery="example-gallery"
                                   class="d-block hover-option  img-fluid">
                                    <div class="text-center text-white padding-top-n-10">
                                        <h1 style="font-size: 75px;">1968</h1><br>
                                        <p style="font-size: 20px;">OUR FIRST PULP AND PAPER MILL


                                        </p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <!--   <div class="padding-30px">
                               <div class="post-entry">
                                   <div class="d-block text-up-small text-grey-4 margin-bottom-15px wow fadeInLeft">
                                       <p>There are many variations of passages of Lorem Ipsum available, but the majority
                                           have
                                           suffered alteration in some form, by injected humour, or randomised words which
                                           don't look
                                           even slightly believable. If you are going to use a passage of Lorem Ipsum, you
                                           need
                                           to be
                                           sure there isn't anything embarrassing hidden in the middle of text. All the
                                           Lorem
                                           Ipsum
                                           generators on the Internet tend to repeat predefined chunks as necessary, making
                                           this the
                                           first true generator on the Internet. It uses a dictionary of over 200 Latin
                                           words,
                                           combined
                                           with a handful of model sentence structures, to generate Lorem Ipsum which looks
                                           reasonable.
                                           The generated Lorem Ipsum is therefore always free from repetition, injected
                                           humour,
                                           or
                                           non-characteristic words etc.
                                       </p>

                                   </div>
                               </div>
                           </div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
@endsection