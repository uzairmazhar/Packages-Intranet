@extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <div class="padding-tb-40px background-light-grey" style="transform: none;">
        <div class="container" style="transform: none;">

            <div class="row" style="transform: none;">
                <!--  content -->

                <div class="col-lg-12 col-md-10 sticky-content"
                     style="position: relative; overflow: visible; box-sizing: border-box; min-height: 870px;">
                    <section class="background-grey-1 padding-tb-25px text-grey-4">
                        <div class="container">
                            <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px">
                                <h3> About Us</h3>
                            </h6>
                            <div class="clearfix">

                            </div>
                        </div>
                    </section>
                    <div  class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px wow fadeInRight">
                        <ul class="row no-gutters padding-0px margin-0px list-unstyled">
                            <li class="col-lg-12 col-md-6 with-hover">
                                <img src="{{asset('assets\img\slider-1.jpg')}}" alt="">
                                <a href="{{URL::to('assets\img\slider-1.jpg')}}" data-toggle="lightbox"
                                   data-gallery="example-gallery"
                                   class="d-block hover-option img-fluid">

                                </a>
                            </li>
                        </ul>
                        <div class="padding-30px">
                            <div class="post-entry">
                                <div class="d-block text-up-small text-grey-4 margin-bottom-15px wow fadeInLeft">
                                    <p>
                                        Packages Limited was established in 1957 as a joint venture between the Ali
                                        Group of Pakistan and Akerlund & Rausing of Sweden, to convert paper and
                                        paperboard into packaging for consumer industry. Over the years, the Company
                                        continued to enhance its facilities to meet the growing demand of packaging
                                        products. Additional capital was raised from sponsors, International Finance
                                        Corporation and from the public in 1965. Packages commissioned its own paper
                                        mill in 1968 having production capacity of 24,000 tonnes of paper and paperboard
                                        based on waste paper and agricultural by-products i.e. wheat straw and river
                                        grass. With growing demand the capacity was increased periodically and in
                                        January 2003 was nearly 100,000 tonnes per year. Since 1982, Packages Limited
                                        has a joint venture with Tetra Pak International in Tetra Pak Pakistan limited
                                        to manufacture paperboard for liquid food packaging and to market Tetra Pak
                                        packaging equipment. In 1993, a joint venture agreement was signed with
                                        Mitsubishi Corporation of Japan for the manufacture of Polypropylene films at
                                        the Industrial Estate in Hattar, NWFP. This project, Tri-Pack Films Limited,
                                        commenced production in June, 1995 with equity participation by Packages
                                        Limited, Mitsubishi Corporation, Altawfeek Company for Investment Funds, Saudi
                                        Arabia and general public. Packages Limited owns 33% of Tri-Pack Films Limited's
                                        equity. In July, 1994, Coates Lorilleux Pakistan Limited, in which Packages
                                        Limited has 55% ownership, commenced production and sale of printing inks. In
                                        1996, a joint venture agreement was signed with Printcare (Ceylon) Limited for
                                        the production of flexible packaging materials in Sri Lanka. This project
                                        Packages Lanka (Private) Limited commenced production in 1998. Packages Limited
                                        now owns 77% of this company. In 1999-2000 Packages Limited has successfully
                                        completed the expansion of the flexible packaging line by installation of new
                                        rotogravure printing machine and the expansion of the carton line by a new
                                        Lemanic rotogravure inline printing and cutting creasing machine. In addition a
                                        new 8 color flexo graphic printing machine was also installed in flexible
                                        packaging line in 2001. Packages Limited has also started producing corrugated
                                        boxes from its plant in Karachi from 2002.

                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
@endsection