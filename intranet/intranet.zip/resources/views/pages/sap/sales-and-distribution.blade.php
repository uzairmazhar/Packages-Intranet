@extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <div class="padding-tb-100px">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs " role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#m_tabs_7_1" role="tab">
                                CPD
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_2" role="tab">
                                BSPM_PBD
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_3" role="tab">
                                PACK
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_4" role="tab">
                                SALES FLOW CHART
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_5" role="tab">
                                RSF ENGINE
                            </a>
                        </li>


                    </ul>
                    <div class="tab-content">
                        <div class=" tab-pane active padding-30px active show" id="m_tabs_7_1" role="tabpanel">

                            <table class="table m-table m-table--head-bg-success">
                                <thead>
                                <tr>
                                    <th>
                                        Serial No.
                                    </th>
                                    <th>
                                        Description
                                    </th>
                                    <th>
                                        Action
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row">
                                        1
                                    </th>
                                    <td>
                                        Customer Master
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>
                                <tr>
                                    <th scope="row">
                                        2
                                    </th>
                                    <td>
                                        Dispatch
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>

                                <tr>
                                    <th scope="row">
                                        3
                                    </th>
                                    <td>
                                        Sale Order
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>

                                </tbody>
                            </table>

                        </div>
                        <div class=" tab-pane  padding-30px" id="m_tabs_7_2" role="tabpanel">

                            <table class="table m-table m-table--head-bg-success">
                                <thead>
                                <tr>
                                    <th>
                                        Serial No.
                                    </th>
                                    <th>
                                        Description
                                    </th>
                                    <th>
                                        Action
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row">
                                        1
                                    </th>
                                    <td>
                                        Customer Master Accounts
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>
                                <tr>
                                    <th scope="row">
                                        2
                                    </th>
                                    <td>
                                        Customer Master Sales
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>

                                <tr>
                                    <th scope="row">
                                        3
                                    </th>
                                    <td>
                                        Dispatch
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>
                                <tr>
                                    <th scope="row">
                                        4
                                    </th>
                                    <td>
                                        Sale Order
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>


                                </tbody>
                            </table>

                        </div>
                        <div class=" tab-pane  padding-30px" id="m_tabs_7_3" role="tabpanel">

                            <table class="table m-table m-table--head-bg-success">
                                <thead>
                                <tr>
                                    <th>
                                        Serial No.
                                    </th>
                                    <th>
                                        Description
                                    </th>
                                    <th>
                                        Action
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row">
                                        1
                                    </th>
                                    <td>
                                        Customer Master
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>

                                <tr>
                                    <th scope="row">
                                        2
                                    </th>
                                    <td>
                                        Dispatch
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>
                                <tr>
                                    <th scope="row">
                                        3
                                    </th>
                                    <td>
                                        Sale Order
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>


                                </tbody>
                            </table>

                        </div>
                        <div class=" tab-pane  padding-30px" id="m_tabs_7_4" role="tabpanel">

                            <table class="table m-table m-table--head-bg-success">
                                <thead>
                                <tr>
                                    <th>
                                        Serial No.
                                    </th>
                                    <th>
                                        Description
                                    </th>
                                    <th>
                                        Action
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row">
                                        1
                                    </th>
                                    <td>
                                        Sales Flow Chart
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>


                                </tbody>
                            </table>

                        </div>
                        <div class=" tab-pane  padding-30px" id="m_tabs_7_5" role="tabpanel">

                            <table class="table m-table m-table--head-bg-success">
                                <thead>
                                <tr>
                                    <th>
                                        Serial No.
                                    </th>
                                    <th>
                                        Description
                                    </th>
                                    <th>
                                        Action
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row">
                                        1
                                    </th>
                                    <td>
                                        RSF Engine
                                    </td>
                                    <td>
                                        <div class="m-widget4__ext">
                                            <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                               target="_blank">
                                                <p class="DownloadPDFContent"
                                                   style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                    Download PDF
                                                </p>
                                                <i class="fa fa-download"></i>
                                            </a>
                                        </div>
                                    </td>

                                </tr>

                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('footer')
@endsection