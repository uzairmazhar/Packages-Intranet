
@extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <div class="padding-tb-40px background-light-grey" style="transform: none;">
        <div class="container" style="transform: none;">
            <div class="row" style="transform: none;">

                <!--  content -->
                <div class="col-lg-12 col-md-12 sticky-content wow fadeInUp"
                     style="position: relative; overflow: visible; box-sizing: border-box; min-height: 1px;">
                    <table id="example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <h3>Plant Maintenance</h3>
                        </tr>
                        </thead>
                        <tbody>
                        <tr class="wow fadeInLeft">
                            <td style="font-size: medium">PM_TM_Equipment<a href="{{asset('#')}}"
                                                                            target="_blank"> <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>

                        </tr>
                        <tr class="wow fadeInRight">
                            <td style="font-size: medium">PM_TM_Functional Location <a href="{{asset('#')}}"
                                                                                       target="_blank">
                                    <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>
                        </tr>
                        <tr class="wow fadeInLeft">
                            <td style="font-size: medium">PM_TM_Maintainance Plan <a href="{{asset('#')}}"
                                                                                     target="_blank"> <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>

                        </tr>
                        <tr class="wow fadeInRight">
                            <td style="font-size: medium">Create Production Order <a href="{{asset('#')}}"
                                                                                     target="_blank">
                                    <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>
                        </tr>
                        <tr class="wow fadeInLeft">
                            <td style="font-size: medium">PM_TM_Notification <a href="{{asset('#')}}"
                                                                                target="_blank"> <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>

                        </tr>
                        <tr class="wow fadeInRight">
                            <td style="font-size: medium">Personnel Administration <a href="{{asset('#')}}"
                                                                                      target="_blank">
                                    <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>
                        </tr>
                        <tr class="wow fadeInLeft">
                            <td style="font-size: medium">PM_TM_Task List <a href="{{asset('#')}}"
                                                                             target="_blank"> <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>

                        </tr>
                        <tr class="wow fadeInRight">
                            <td style="font-size: medium">PM_TM_Work Centre <a href="{{asset('#')}}" target="_blank">
                                    <i
                                            class="fa fa-fw" aria-hidden="true" title="Copy to use download"
                                            style="float: right; height: 30px"></i></a></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <!-- //  content -->

            </div>
        </div>
    </div>
@endsection
@section('footer')
@endsection