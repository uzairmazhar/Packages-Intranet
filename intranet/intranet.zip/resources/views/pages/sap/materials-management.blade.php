@extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <div class="padding-tb-100px">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_1" role="tab">
                                MATERIAL MASTER
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_2" role="tab">

                                VENDOR MASTER
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_3" role="tab">

                                LOGISTICS INVOICES
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_4" role="tab">
                                GOODS ISSUES
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_5" role="tab">
                                GOODS RECEIPTS
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_6" role="tab">
                                TRANSFER POSTING
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_7" role="tab">
                                REQUEST FOR QUOTATIONS
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " data-toggle="tab" href="#m_tabs_7_8" role="tab">
                                PURCHASE ORDERS
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#m_tabs_7_9" role="tab">
                                PURCHASE REQUISITION
                            </a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div class="tab-content">
                            <div class="tab-pane active padding-30px" id="m_tabs_7_1" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            Material Master Change
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            Vendor Master Change
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            Material Master Create (Misc)
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            4
                                        </th>
                                        <td>
                                            Material Master Create Raw
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            5
                                        </th>
                                        <td>
                                            Material Master Create Spares
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            6
                                        </th>
                                        <td>
                                            Material Master Plant Extension
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            7
                                        </th>
                                        <td>
                                            Material Master Storage Location Extension
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane padding-30px" id="m_tabs_7_2" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            Vendor Master Create Local
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            Vendor Master Change
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            Vendor Master Create Import
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>


                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane padding-30px" id="m_tabs_7_3" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            Advances to Supplier Request
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            Park Invoice
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>


                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane padding-30px" id="m_tabs_7_4" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            GI for Asset
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            GI for Cost Center
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            GI for STO
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            4
                                        </th>
                                        <td>
                                            GI for Sub contracting PO
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            5
                                        </th>
                                        <td>
                                            GI Store Return(202)
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    </tbody>
                                </table>

                            </div>

                            <div class="tab-pane padding-30px" id="m_tabs_7_5" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            GR for PO Import
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            GR for PO Local
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            GI for STO
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            4
                                        </th>
                                        <td>
                                            GI for Sub contracting PO
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            5
                                        </th>
                                        <td>
                                            GI Store Return(202)
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            6
                                        </th>
                                        <td>
                                            GR Via Qaulity Inspection
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            7
                                        </th>
                                        <td>
                                            Material Document Cancellation
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            8
                                        </th>
                                        <td>
                                            Service EntrySheet for PO
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane padding-30px" id="m_tabs_7_6" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            TF SLoc to SLoc Step1
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            TF SLoc to SLoc Step2
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            TF Material to Material
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            4
                                        </th>
                                        <td>
                                            TF Plant to Plant
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane padding-30px" id="m_tabs_7_7" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            Maintain Quotation
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            Price Comparision
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            RFQ Change
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            4
                                        </th>
                                        <td>
                                            RFQ Create
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            5
                                        </th>
                                        <td>
                                            RFQ Print Out
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane padding-30px" id="m_tabs_7_8" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            PO Change Import Charges
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            PO Create Import
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            PO Create Internal
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            4
                                        </th>
                                        <td>
                                            PO Create Local
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            5
                                        </th>
                                        <td>
                                            PO Create Services
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            6
                                        </th>
                                        <td>
                                            PO Create STO
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            7
                                        </th>
                                        <td>
                                            PO Create Sub contracting
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            8
                                        </th>
                                        <td>
                                            PO Create Zero Value
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            9
                                        </th>
                                        <td>
                                            PO Print Out
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            10
                                        </th>
                                        <td>
                                            PO Release
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            11
                                        </th>
                                        <td>
                                            PO Release Cancel and Change
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane padding-30px" id="m_tabs_7_9" role="tabpanel">

                                <table class="table m-table m-table--head-bg-success">
                                    <thead>
                                    <tr>
                                        <th>
                                            Serial No.
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">
                                            1
                                        </th>
                                        <td>
                                            PR Change
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            2
                                        </th>
                                        <td>
                                            PR Create Consumables
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>

                                    <tr>
                                        <th scope="row">
                                            3
                                        </th>
                                        <td>
                                            PR Create Material
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            4
                                        </th>
                                        <td>
                                            PR Create Services
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            5
                                        </th>
                                        <td>
                                            PR Create Sub contracting
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            6
                                        </th>
                                        <td>
                                            PR Creation Assets
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            7
                                        </th>
                                        <td>
                                            PR Display
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            8
                                        </th>
                                        <td>
                                            PR Print Out
                                        </td>
                                        <td>
                                            <div class="m-widget4__ext">
                                                <a href="{{asset('assets/docs/reports/annual-report-2016.pdf')}}" class="m-widget4__icon"
                                                   target="_blank">
                                                    <p class="DownloadPDFContent"
                                                       style=" display:  inline-block; margin: 0;padding-right: 10px;">
                                                        Download PDF
                                                    </p>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                        </td>

                                    </tr>
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                    <!-- // Nav tabs -->
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
@endsection