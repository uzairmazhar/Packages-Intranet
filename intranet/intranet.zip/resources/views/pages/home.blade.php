@extends('layouts.web-layout')
@section('header')
@endsection
@section('body')
<section>
    <div id="rev_slider_37_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="The-Nile-20" data-source="gallery">
        <div id="rev_slider_37_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.1">
            <ul>
                <li data-index="rs-100" data-transition="fade" data-slotamount="default" data-hideafterloop="0"1
                    data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300"
                    data-thumb="assets/100x50_98efd-29.jpg" data-rotate="0" data-saveperformance="off"
                    data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5=""
                    data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <video autoplay="" loop="" muted="" style="height:auto;">
                        <source src="{{asset('assets/img/video_preview_h264.mp4')}}" data-bgposition="center center" type="video/mp4">
                    </video>
                    <div class="tp-caption tp-resizeme" id="slide-100-layer-1"
                         data-x="['center','left','center','center']" data-hoffset="['3','53','0','3']"
                         data-y="['top','top','top','top']" data-voffset="['253','235','177','175']"
                         data-fontsize="['94','75','75','50']" data-lineheight="['50','50','50','40']"
                         data-fontweight="['300','700','700','700']"
                         data-color="['rgb(178,178,178)','rgb(255,58,45)','rgb(255,58,45)','rgb(255,58,45)']"
                         data-letterspacing="['-1','0','0','0']" data-width="['388','385','345','456']"
                         data-height="['52','56','54','none']" data-whitespace="normal" data-type="text"
                         data-responsive_offset="on"
                         data-frames='[{"delay":550,"speed":750,"frame":"0","from":"y:50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                         data-textAlign="['left','left','center','center']" data-paddingtop="[0,0,0,0]"
                         data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                         style="z-index: 5; min-width: 388px; max-width: 388px; max-width: 52px; max-width: 52px; white-space: normal; font-size: 94px; line-height: 50px; font-weight: 300; color: #b2b2b2;font-family:Poppins;">
                    </div>
                </li>
            </ul>
            <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
        </div>
    </div>
    <div>
        <marquee style="background-color:#1d78cb; color:#ffffff; padding: 7px 0px;" onmousedown="this.stop();" onmouseup="this.start();">
            This isbasic example of news Feed
        </marquee>
    </div>
</section>
<div class="padding-tb-10px background-light-grey" style="background: whitesmoke">
    <div class="container">

        <div class="text-center margin-bottom-35px fadeInUp">
            <h1 class="font-weight-300 text-title-large font-3">Circulars</h1>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6 sm-mb-30px wow fadeInUp" data-wow-delay="0.2s"
                 style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                <div class="blog-item thum-hover background-white hvr-float hvr-sh2">
                    <a href="#" class="text-extra-large d-block padding-top-20px padding-lr-30px">INTERNAL JOB
                        ANNOUNCEMENT</a>
                    <hr>
                    <div class="padding-lr-30px">
                        <span class="margin-right-30px"><a
                                    href="{{asset('assets/img/Circular/Internal Job Announcement - AM QA.docx')}}">Internal
                                Job Announcement <i class="fa fa-fw" aria-hidden="true"
                                                    title="Copy to use arrow-circle-down"></i> </a></span><br>
                        <span class="margin-right-30px"> <a
                                    href="{{asset('assets/img/Circular/Internal Job Application Form - New.docx')}}">Internal
                                Job Application Form <i class="fa fa-fw" aria-hidden="true"
                                                        title="Copy to use arrow-circle-down"></i> </a>
                            <!--<a href="#">Articles</a>--></span>
                    </div>
                    <hr class="margin-bottom-0px">
                    <div class="position-relative">
                        <div class="date z-index-10 width-50px padding-10px background-main-color text-white text-center position-absolute top-20px left-20px">
                            17/2 2018
                        </div>

                        <a href="#">
                            <div class="item-thumbnail background-dark"><img
                                        src="{{asset('assets/img/Circular/image001-1.png')}}" alt="">
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 sm-mb-30px wow fadeInUp" data-wow-delay="0.4s"
                 style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
                <div class="blog-item background-main-color padding-40px text-center hvr-float hvr-sh2">
                    <a href="#" class="text-extra-large margin-tb-20px d-block text-white">He who makes no mistakes
                        makes nothing</a>
                    <hr>
                    <span class="margin-right-30px text-white opacity-5">By : <a href="#">Rabie Elkheir</a></span>
                    <hr>
                    <span class="margin-right-30px text-white  opacity-5">In : <a href="#">News</a> , <a href="#">Articles</a></span>
                    <hr>
                    <div class="text-grey-2 text-white  opacity-6">There are many variations of passages of Lorem
                        Ipsum
                        available, but the majority have suffered alteration in some form, by injected humour ...
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 sm-mb-30px wow fadeInUp" data-wow-delay="0.2s"
                 style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                <div class="blog-item thum-hover background-white hvr-float hvr-sh2">
                    <a href="#" class="text-extra-large d-block padding-top-20px padding-lr-30px">INTERNAL JOB
                        ANNOUNCEMENT</a>
                    <hr>
                    <div class="padding-lr-30px">
                        <span class="margin-right-30px"><a
                                    href="{{asset('assets/img/Circular/Internal Job Announcement - AM QA.docx')}}">Internal
                                Job Announcement <i class="fa fa-fw" aria-hidden="true"
                                                    title="Copy to use arrow-circle-down"></i> </a></span><br>
                        <span class="margin-right-30px"> <a
                                    href="{{asset('assets/img/Circular/Internal Job Application Form - New.docx')}}">Internal
                                Job Application Form <i class="fa fa-fw" aria-hidden="true"
                                                        title="Copy to use arrow-circle-down"></i> </a>
                            <!--<a href="#">Articles</a>--></span>
                    </div>
                    <hr class="margin-bottom-0px">
                    <div class="position-relative">
                        <div class="date z-index-10 width-50px padding-10px background-main-color text-white text-center position-absolute top-20px left-20px">
                            17/2 2018
                        </div>

                        <a href="#">
                            <div class="item-thumbnail background-dark"><img
                                        src="{{asset('assets/img/Circular/image001-1.png')}}" alt="">
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- //container -->
</div>
<!--End Circulars-->
<!-- page output -->
<div class=" col-lg-12 wow fadeInUp"
     style="visibility: visible; animation-name: fadeInUp; padding-top:40px; background-color: whitesmoke;">
    <div class="container">
        <div class="row">
            <!--  content -->
            <!--Begin TimeLine-->
            <!-- page output -->
            <div class="col-lg-12" style="padding:0px; background: #fafafa;">
                <div class="container"
                     style="background: #ffffff;border-color: #eeeded;border-width: 1px;border-style:solid;  ">
                    <!--Begin TimeLine Header-->
                    <section class="background-grey-1 padding-tb-25px text-grey-4"
                             style="padding-bottom: 0px;padding-top:0px; background:#ffffff;border-color: #eeeded; border-bottom-width: 1px;border-bottom-style:solid;margin-bottom: 20px;  ">
                        <!--End TimeLine Header-->
                        <div class="container">
                            <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px"
                                style="padding-bottom: 0;"><p
                                        class="btn btn-sm border-2 border-radius-30 btn-block background-third-color text-white" style="font-size: 20px;">
                                    <i
                                            class="fa fa-fw" aria-hidden="true" title="Timelien"></i> Timeline</p>
                            </h6>
                            <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
                                <li class="active"><a href="{{URL::to('pic-video')}}" target="_blank"
                                                      class="btn btn-sm border-2 border-radius-30 btn-danger btn-block">
                                        <i class="fa fa-fw" aria-hidden="true" title="Copy to use television"></i>
                                        Gallery
                                    </a></li>
                            </ol>
                            <div class="clearfix"></div>
                        </div>
                    </section>

                    <div class="row">
                        <div class="col-lg-12 col-md-12">

                            <div class="timeline">

                                <!-- timeline item -->
                                <div class="timeline-item row">
                                    <div class="col-1 date border-right-2 border-main-color">
                                        <h6 class="text-third-color">19:45</h6>
                                    </div>
                                    <div class="col-11 post padding-bottom-30px">
                                        <!-- <img style="max-width: 60px;height: auto;"
                                             src="{{asset('http://placehold.it/60x60')}}"
                                             class="float-left margin-right-20px margin-bottom-20px" alt="">-->
                                        <i style="max-width: 60px;height: auto; font-size: 60px; color: sandybrown;"
                                           class="fa fa-fw float-left margin-right-20px margin-bottom-20px"
                                           aria-hidden="true"
                                           title="Copy to use birthday-cake"></i>
                                        <h5 class="text-medium text-dark text-uppercase  margin-top-8px"><a
                                                    href="{{URL::to('#')}}" target="_blank">Away Day</a></h5>
                                        <span class="text-extra-small text-grey-3">Date :  <a href="#"
                                                                                              class="text-grey-3">July
                                                15, 2016</a></span>
                                        <a href="pic-video" target="_blank">
                                            <br>
                                            <!--<h2>Away Day</h2>-->
                                            <ul style="overflow: hidden; list-style:  none; float: left; padding-left: 0">

                                                <li style="float: right;  padding-left: 2px;">
                                                    <div class="with-hover hvr-float hvr-sh2">
                                                        <img style="max-width: 60px;height: auto;"
                                                             src="{{asset('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_001.JPG')}}"
                                                             alt="">
                                                        <a href="{{URL::to('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_001.JPG')}}"
                                                           target="_blank"
                                                           data-toggle="lightbox"
                                                           data-gallery="example-gallery"
                                                           class="d-block hover-option  img-fluid">

                                                        </a>
                                                    </div>
                                                </li>
                                                <li style="float: right;  padding-left: 2px;">
                                                    <div class="with-hover hvr-float hvr-sh2">
                                                        <img style="max-width: 60px;height: auto;"
                                                             src="{{asset('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_002.JPG')}}"
                                                             alt="">
                                                        <a href="{{URL::to('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_002.JPG')}}"
                                                           target="_blank"
                                                           data-toggle="lightbox"
                                                           data-gallery="example-gallery"
                                                           class="d-block hover-option  img-fluid">

                                                        </a>
                                                    </div>
                                                </li>
                                                <li style="float: right; padding-left: 2px;">
                                                    <div class="with-hover hvr-float hvr-sh2">
                                                        <img style="max-width: 60px;height: auto;"
                                                             src="{{asset('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_003.JPG')}}"
                                                             alt="">
                                                        <a href="{{URL::to('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_003.JPG')}}"
                                                           target="_blank"
                                                           data-toggle="lightbox"
                                                           data-gallery="example-gallery"
                                                           class="d-block hover-option  img-fluid">

                                                        </a>
                                                    </div>
                                                </li>
                                                <li style="float: right; padding-left: 2px;">
                                                    <div class="with-hover hvr-float hvr-sh2">
                                                        <img style="max-width: 60px;height: auto;"
                                                             src="{{asset('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_004.JPG')}}"
                                                             alt="">
                                                        <a href="{{URL::to('assets/img/intranet/TRAININGS/FC AWAY DAY/200517_004.JPG')}}"
                                                           target="_blank"
                                                           data-toggle="lightbox"
                                                           data-gallery="example-gallery"
                                                           class="d-block hover-option  img-fluid">

                                                        </a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </a>

                                    </div>
                                </div>
                                <!-- //  timeline item -->


                                <!-- timeline item -->
                                <div class="timeline-item row">
                                    <div class="col-1 date border-right-2 border-main-color">
                                        <h6 class="text-third-color">19:45</h6>
                                    </div>
                                    <div class="col-11 post padding-bottom-30px">
                                        <!-- <img style="max-width: 60px;height: auto;"
                                             src="{{asset('http://placehold.it/60x60')}}"
                                             class="float-left margin-right-20px margin-bottom-20px" alt="">-->
                                        <i style="max-width: 60px;height: auto; font-size: 60px; color: pink"
                                           class="fa fa-fw float-left margin-right-20px margin-bottom-20px"
                                           aria-hidden="true" title="Copy to use birthday-cake"></i>
                                        <h5 class="text-medium text-dark text-uppercase  margin-top-8px">Nauman
                                            Abid Happy Birthday</h5>
                                        <span class="text-extra-small text-grey-3">
                                            <i class="fa fa-fw" aria-hidden="true" title="Copy to use gift"></i>
                                            <a href="#"
                                               class="text-grey-3">
                                                Aug 27,1995</a></span>

                                    </div>
                                </div>
                                <!-- //  timeline item -->


                                <!-- timeline item -->
                                <div class="timeline-item row">
                                    <div class="col-1 date border-right-2 border-main-color">
                                        <h6 class="text-third-color">20:00</h6>
                                    </div>
                                    <div class="col-11 post padding-bottom-30px">
                                        <img style="max-width: 60px;height: auto;"
                                             src="{{asset('assets/img/icon/man-icon.jpg')}}"
                                             class="float-left margin-right-20px margin-bottom-20px" alt="">
                                        <h5 class="text-medium text-dark text-uppercase  margin-top-8px">Anonymous</h5>
                                        <span class="text-extra-small text-grey-3">Date :  <a href="#"
                                                                                              class="text-grey-3">July
                                                15, 2016</a></span>
                                        <p class="text-main-color-2">There are many variations of passages of Lorem
                                            Ipsum available,
                                            but the majority have suffered alteration in some form, by injected
                                            humour,
                                            or
                                            randomised words which don't look even slightly believable. If you are
                                            going
                                            to use a
                                            passage of Lorem Ipsum</p>
                                    </div>
                                </div>
                                <!-- //  timeline item -->

                            </div>

                        </div>
                    </div>
                    <!-- Begin TimeLine LoadMore --->
                    <section class="background-grey-1 padding-tb-25px text-grey-4"
                             style="background: #ffffff; padding-top: 0px">
                        <div class="container" style="max-width: 200px">
                            <a href="{{URL::to('timeline-see-more')}}" target="_blank"
                               class="btn btn-sm border-2 border-radius-30 btn-danger btn-block"
                               style="padding: 0 auto;">Read More</a>
                            <div class="clearfix"></div>
                        </div>
                    </section>
                    <!-- End TimeLine LoadMore --->
                </div>
            </div>
            <!-- //  page output -->
            <!--End TimeLine-->
            <!--Begin Sab Keh Doo-->

            <div class="col-lg-8 col-md-8 fadeInUp" style="animation-name: fadeInUp;margin-top: 40px;">
                <!--Begin Sab Keh Doo Header-->
                <section class="background-grey-1 padding-tb-25px text-grey-4"
                         style="padding-bottom: 0px;padding-top:0px; background: #ffffff; border-color: #eeeded; border-width: 1px;border-style:solid; ">
                    <div class="container">
                        <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px"
                            style="padding-bottom: 0; "><p
                                    class="btn btn-sm border-2 border-radius-30 btn-block background-third-color text-white"
                                    style=" font-size: 20px;margin-bottom: 0">
                                <i class="fa fa-fw" aria-hidden="true" title="TimeLine"></i> Sab Keh Doo</p>
                        </h6>
                        <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
                            <li class="active"><a href="{{URL::to('#')}}" target="_blank"
                                                  class="btn btn-sm border-2 border-radius-30 btn-danger btn-block"> See
                                    More
                                </a>
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </section>
                <!--End Sab Keh Doo Header-->
                <!--Begin Style -->
                <style>
                    .SabKehDo::-webkit-scrollbar {
                        margin: 0;
                        padding: 0;
                        height: 100%;
                        width: 120%;
                    }

                    .SabKehDo::-webkit-scrollbar-thumb {
                        border-radius: 10px;
                        background-color: black;
                        box-shadow: inset 0 0 6px rgba(0, 0, 0, .3);
                    }
                </style>
                <!--End Style -->
                <div class="SabKehdo"
                     style="overflow: scroll; max-height: 550px;border-color: #eeeded; border-width: 1px;border-style:solid;border-top: 0">
                    <!--  Begin Posts  -->
                    <div class="background-white margin-bottom-35px padding-30px  hvr-float hvr-sh2"
                         style="margin-bottom: 0;">
                        <img style="max-width: 60px;height: auto;"
                             src="{{asset('assets/img/intranet/PICTURES OF PACKAGES LIMITED (SLIDE SHOW)/IMG_6635.JPG')}}"
                             class="float-left margin-right-20px margin-bottom-20px"
                             alt="">
                        <h5 class="text-medium text-dark text-uppercase  margin-top-8px">Rabie Elkheir</h5>
                        <span class="text-extra-small text-grey-3">Date :  <a href="#" class="text-grey-3">July 15,
                                2016</a></span>
                        <div class="clearfix"></div>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, eveniet, eligendi et
                        nobis
                        neque minus mollitia sit repudiandae ad repellendus recusandae blanditiis praesentium vitae
                        ab
                        sint earum voluptate velit beatae alias fugit accusantium laboriosam nisi reiciendis
                        deleniti
                        tenetur molestiae maxime id quaerat consequatur fugiat aliquam laborum nam aliquid.
                        Consectetur,
                        perferendis?
                    </div>
                    <!-- End Posts  -->
                    <!--  Begin Posts  -->
                    <div class="background-white margin-bottom-35px padding-30px  hvr-float hvr-sh2"
                         style="margin-bottom: 0;">
                        <img style="max-width: 60px;height: auto;" src="{{asset('http://placehold.it/60x60')}}"
                             class="float-left margin-right-20px margin-bottom-20px"
                             alt="">
                        <h5 class="text-medium text-dark text-uppercase  margin-top-8px">Nauman Abid</h5><span
                                class="text-extra-small text-grey-3">Date :  <a href="#" class="text-grey-3">July 15,
                                2016</a></span>
                        <div class="clearfix"></div>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, eveniet, eligendi et
                        nobis
                        neque minus mollitia sit repudiandae ad repellendus recusandae blanditiis praesentium vitae
                        ab
                        sint earum voluptate velit beatae alias fugit accusantium laboriosam nisi reiciendis
                        deleniti
                        tenetur molestiae maxime id quaerat consequatur fugiat aliquam laborum nam aliquid.
                        Consectetur,
                        perferendis?
                    </div>
                    <!-- End Posts  -->
                    <!--  Begin Posts  -->
                    <div class="background-white margin-bottom-35px padding-30px  hvr-float hvr-sh2"
                         style="margin-bottom: 0;">
                        <img style="max-width: 60px;height: auto;" src="{{asset('http://placehold.it/60x60')}}"
                             class="float-left margin-right-20px margin-bottom-20px"
                             alt="">
                        <h5 class="text-medium text-dark text-uppercase  margin-top-8px">Anonymous</h5>
                        <span class="text-extra-small text-grey-3">Date :  <a href="#" class="text-grey-3">July 15,
                                2016</a></span>
                        <div class="clearfix"></div>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, eveniet, eligendi et
                        nobis
                        neque minus mollitia sit repudiandae ad repellendus recusandae blanditiis praesentium vitae
                        ab
                        sint earum voluptate velit beatae alias fugit accusantium laboriosam nisi reiciendis
                        deleniti
                        tenetur molestiae maxime id quaerat consequatur fugiat aliquam laborum nam aliquid.
                        Consectetur,
                        perferendis?
                    </div>
                    <!-- End Posts  -->
                    <!--  Begin Posts  -->
                    <div class="background-white margin-bottom-35px padding-30px  hvr-float hvr-sh2"
                         style="margin-bottom: 0;">
                        <img style="max-width: 60px;height: auto;" src="{{asset('http://placehold.it/60x60')}}"
                             class="float-left margin-right-20px margin-bottom-20px"
                             alt="">
                        <h5 class="text-medium text-dark text-uppercase  margin-top-8px">Abdul Haseeb Khan</h5>
                        <span class="text-extra-small text-grey-3">Date :  <a href="#" class="text-grey-3">July 15,
                                2016</a></span>
                        <div class="clearfix"></div>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, eveniet, eligendi et
                        nobis
                        neque minus mollitia sit repudiandae ad repellendus recusandae blanditiis praesentium vitae
                        ab
                        sint earum voluptate velit beatae alias fugit accusantium laboriosam nisi reiciendis
                        deleniti
                        tenetur molestiae maxime id quaerat consequatur fugiat aliquam laborum nam aliquid.
                        Consectetur,
                        perferendis?
                    </div>
                    <!-- End Posts  -->
                </div>
            </div>
            <!-- //  content -->
            <!-- sidebar -->
            <div class="col-lg-4 col-md-4 wow fadeInUp "
                 style="visibility: visible; animation-name: fadeInUp; margin-top: 40px;">
                <!--Begin Post Form-->
                <div class="widget" style=" height: 600px; ">
                    <h4 class="widget-title clearfix"><span>Feedback</span></h4>

                    <form action="#">
                         <textarea class="form-control rounded-0" style="margin-top:20px; "
                                   placeholder="Your Feedback"></textarea>
                        <input id="anon" style="margin-left: 10px;margin-top: 10px;" type="radio" name="anonymous" aria-checked="true"
                               value="anonymous"> Anonymous<br>
                        <input id="non" onchange="" style="margin-left: 10px;margin-top: 10px;" type="radio"
                               name="anonymous" value="nonAnonymous"> Non Anonymous<br>

                        <div class="non-anonymous" style="display: none;">
                            <input class="form-control rounded-0 margin-tb-10px" type="email" placeholder="Enter Email">
                            <p class="widget-title clearfix" style="text-align: center;font-size:20px;color:gray ">
                                <span>OR</span></p>
                            <input class="form-control rounded-0 margin-tb-10px" type="email"
                                   placeholder="Enter Employee ID">

                        </div>
                        <input class="btn text-white text-uppercase text-small btn-block margin-top-15px background-grey-3 rounded-0 border-0"
                               type="submit" value="Submit">
                    </form>


                    <script>
                        $('#non').click(function () {
                            $('.non-anonymous').css('display', 'block');
                        });

                        $('#anon').click( function() {

                            $('.non-anonymous').css('display', 'none');
                        })
                        ;</script>


                </div>
                <!-- End Post Form -->

            </div>
            <!-- // sidebar -->
            <!--End Seb Keh Doo-->
        </div>
    </div>
</div>
<!-- //  page output -->
<!--Begin Second Sab Keh Doo-->
<!--<section class="padding-tb-100px background-light-grey">
    <section class="background-grey-1 padding-tb-25px text-grey-4"
             style="padding-bottom: 0px;padding-top:0px; background: #ffffff; border-color: #eeeded; border-width: 1px;border-style:solid; ">
        <div class="container">
            <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px"
                style="padding-bottom: 0;"><p
                        class="btn btn-sm border-2 border-radius-30 btn-block background-third-color text-white">
                    <i
                            class="fa fa-fw" aria-hidden="true" title="Timelien"></i> Sab Keh Doo</p>
            </h6>
            <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
                <li class="active"><a href="#"
                                      class="btn btn-sm border-2 border-radius-30 btn-danger btn-block"><i
                                class="fa fa-fw" aria-hidden="true" title="Search ilter"></i>Filter
                    </a>
                </li>
            </ol>
            <div class="clearfix"></div>
        </div>
    </section>
    <div class="container">
        <div class="text-center margin-bottom-35px wow fadeInUp">
            <h1 class="font-weight-300 text-title-large font-3">Testimonial</h1>
            <span class="opacity-7">Lorem Ipsum Dolor Sit Amet, Consectetur Adipisicing Elitdunt</span>
        </div>

        <div class="testimonial-carousel owl-carousel owl-theme wow fadeInUp">
            <div class="item margin-lr-15px">
                <div class="background-white opacity-hover-7 padding-30px">
                    <div class="float-left width-50px margin-right-20px">
                        <img src="http://placehold.it/80x80" alt="">
                    </div>
                    <h4 class="margin-bottom-0px">Rabie Elkheir</h4>
                    <small>Web Designer</small>
                    <hr>
                    <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
                </div>
            </div>
            <div class="item margin-lr-15px">
                <div class="background-white opacity-hover-7 padding-30px">
                    <div class="float-left width-50px margin-right-20px">
                        <img src="http://placehold.it/80x80" alt="">
                    </div>
                    <h4 class="margin-bottom-0px">Firdous Fadlalla</h4>
                    <small>Web Designer</small>
                    <hr>
                    <p class="text-grey-2">The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here'</p>
                </div>
            </div>
            <div class="item margin-lr-15px">
                <div class="background-white opacity-hover-7 padding-30px">
                    <div class="float-left width-50px margin-right-20px">
                        <img src="http://placehold.it/80x80" alt="">
                    </div>
                    <h4 class="margin-bottom-0px">Moh Elkheir</h4>
                    <small>Web Designer</small>
                    <hr>
                    <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
                </div>
            </div>
            <div class="item margin-lr-15px">
                <div class="background-white opacity-hover-7 padding-30px">
                    <div class="float-left width-50px margin-right-20px">
                        <img src="http://placehold.it/80x80" alt="">
                    </div>
                    <h4 class="margin-bottom-0px">Moh Elkheir</h4>
                    <small>Web Designer</small>
                    <hr>
                    <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
                </div>
            </div>
            <div class="item margin-lr-15px">
                <div class="background-white opacity-hover-7 padding-30px">
                    <div class="float-left width-50px margin-right-20px">
                        <img src="http://placehold.it/80x80" alt="">
                    </div>
                    <h4 class="margin-bottom-0px">Moh Elkheir</h4>
                    <small>Web Designer</small>
                    <hr>
                    <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
                </div>
            </div>
            <div class="item margin-lr-15px">
                <div class="background-white opacity-hover-7 padding-30px">
                    <div class="float-left width-50px margin-right-20px">
                        <img src="http://placehold.it/80x80" alt="">
                    </div>
                    <h4 class="margin-bottom-0px">Moh Elkheir</h4>
                    <small>Web Designer</small>
                    <hr>
                    <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
                </div>
            </div>
        </div>


    </div>
</section>-->
<!--End Sab Keh do-->
<!--End Page-->
@endsection
@section('footer')
    <script type="text/javascript">
            var tpj = jQuery;
            var revapi37;
            tpj(document).ready(function () {
                if (tpj("#rev_slider_37_1").revolution == undefined) {
                    revslider_showDoubleJqueryError("#rev_slider_37_1");
                } else {
                    revapi37 = tpj("#rev_slider_37_1").show().revolution({
                        sliderType: "standard",
                        jsFileLocation: "//localhost/revslider-standalone/revslider/public/assets/js/",
                        sliderLayout: "fullwidth",
                        dottedOverlay: "none",
                        delay: 9000,
                        navigation: {
                            onHoverStop: "off",
                        },
                        responsiveLevels: [1240, 1024, 778, 480],
                        visibilityLevels: [1240, 1024, 778, 480],
                        gridwidth: [1110, 1024, 778, 480],
                        gridheight: [720, 720, 500, 500],
                        lazyType: "none",
                        shadow: 0,
                        spinner: "spinner0",
                        stopLoop: "off",
                        stopAfterLoops: -1,
                        stopAtSlide: -1,
                        shuffle: "off",
                        autoHeight: "off",
                        disableProgressBar: "on",
                        hideThumbsOnMobile: "off",
                        hideSliderAtLimit: 0,
                        hideCaptionAtLimit: 0,
                        hideAllCaptionAtLilmit: 0,
                        debugMode: false,
                        fallbacks: {
                            simplifyAll: "off",
                            nextSlideOnWindowFocus: "off",
                            disableFocusListener: false,
                        }
                    });
                }
            });
    </script>
@endsection