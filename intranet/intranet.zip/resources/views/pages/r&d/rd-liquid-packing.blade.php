
@extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <div class="padding-tb-40px background-light-grey" style="transform: none;">
        <div class="container" style="transform: none;">

            <div class="row" style="transform: none;">
                <!--  content -->

                <div class="col-lg-12 col-md-12 sticky-content"
                     style="position: relative; overflow: visible; box-sizing: border-box; min-height: 870px;">
                    <section class="background-grey-1 padding-tb-25px text-grey-4">
                        <div class="container">
                            <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px">
                                <h3>   Straw Pulp to Produce Liquid Packaging Board



                                </h3>
                            </h6>
                            <div class="clearfix">

                            </div>
                        </div>
                    </section>
                    <div class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px wow fadeInRight">
                        <ul class="row no-gutters padding-0px margin-0px list-unstyled">
                            <li class="col-lg-12 col-md-6 with-hover">
                                <img style="width: 100%;height: auto;" src="{{asset('assets/img/liq.jpg')}}"
                                     alt="">
                                <a href="{{URL::to('assets/img/liq.jpg')}}" data-toggle="lightbox"
                                   data-gallery="example-gallery"
                                   class="d-block hover-option background-main-color img-fluid">
                                    <h1 class="text-center text-white padding-top-n-15"><i class="fa fa-search"></i>
                                    </h1>
                                </a>
                            </li>
                        </ul>
                        <div class="padding-30px">
                            <div class="post-entry">
                                <div class="d-block text-up-small text-grey-4 margin-bottom-15px wow fadeInLeft">
                                    <p>

                                        Liquid Packaging Board (LPB) is a very demanding board. Traditionally, it has always been produced with wood pulps. When Packages started production of LPB, we decided to fully exploit the potential of straw pulp in this product. Packages is now successfully producing Liquid Packaging Board using a blend of wood and straw pulps.

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
@endsection