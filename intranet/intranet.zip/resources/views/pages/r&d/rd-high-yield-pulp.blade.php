
    @extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <div class="padding-tb-40px background-light-grey" style="transform: none;">
        <div class="container" style="transform: none;">

            <div class="row" style="transform: none;">
                <!--  content -->

                <div class="col-lg-12 col-md-12 sticky-content"
                     style="position: relative; overflow: visible; box-sizing: border-box; min-height: 870px;">
                    <section class="background-grey-1 padding-tb-25px text-grey-4">
                        <div class="container">
                            <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px">
                                <h3>  High Yield Pulp


                                </h3>
                            </h6>
                            <div class="clearfix">

                            </div>
                        </div>
                    </section>
                    <div class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px wow fadeInRight">
                        <ul class="row no-gutters padding-0px margin-0px list-unstyled">
                            <li class="col-lg-12 col-md-6 with-hover">
                                <img style="width: 100%;height: auto;" src="{{asset('assets/img/straw.jpg')}}"
                                     alt="">
                                <a href="{{URL::to('assets/img/straw.jpg')}}" data-toggle="lightbox"
                                   data-gallery="example-gallery"
                                   class="d-block hover-option background-main-color img-fluid">
                                    <h1 class="text-center text-white padding-top-n-15"><i class="fa fa-search"></i>
                                    </h1>
                                </a>
                            </li>
                        </ul>
                        <div class="padding-30px">
                            <div class="post-entry">
                                <div class="d-block text-up-small text-grey-4 margin-bottom-15px wow fadeInLeft">
                                    <p>
                                        Pckages was the first to build a high yield pulping plant based on wheat straw.
                                        This plant uses a unique pulping process that produces a pulp ideally suited for
                                        the manufacture of test liner and corrugating medium paper for corrugated
                                        containers. The high yield process at Packages is a combination of both
                                        mechanical and chemical cooking followed by refining. The process requires very
                                        mild chemical treatment. The pulp produced has high rigidity and edge crush
                                        resistance making it extremely suitable for liner board and corrugating medium
                                        paper production. The test liner and corrugating medium paper made from this
                                        high yield straw pulp are being converted at Packages to produce high strength
                                        corrugated boxes.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
@endsection