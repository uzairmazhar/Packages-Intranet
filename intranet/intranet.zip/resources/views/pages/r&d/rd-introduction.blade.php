@extends('layouts.web-layout-1')
@section('header')
@endsection
@section('body')
    <div class="padding-tb-40px background-light-grey" style="transform: none;">
        <div class="container" style="transform: none;">

            <div class="row" style="transform: none;">
                <!--  content -->

                <div class="col-lg-12 col-md-12 sticky-content"
                     style="position: relative; overflow: visible; box-sizing: border-box; min-height: 870px;">
                    <section class="background-grey-1 padding-tb-25px text-grey-4">
                        <div class="container">
                            <h6 class="font-weight-300 text-capitalize float-md-left font-2 padding-tb-10px">
                                <h3> Research and Development

                                </h3>
                            </h6>
                            <div class="clearfix">

                            </div>
                        </div>
                    </section>
                    <div class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px wow fadeInRight">
                        <ul class="row no-gutters padding-0px margin-0px list-unstyled">
                            <li class="col-lg-12 col-md-6 with-hover">
                                <img style="width: 100%;height: auto" src="{{asset('assets/img/research.jpg')}}" alt="">
                                <a href="{{URL::to('assets/img/research.jpg')}}" data-toggle="lightbox"
                                   data-gallery="example-gallery"
                                   class="d-block hover-option background-main-color img-fluid">
                                    <h1 class="text-center text-white padding-top-n-10"><i class="fa fa-search"></i>
                                    </h1>
                                </a>
                            </li>
                        </ul>
                        <div class="padding-30px">
                            <div class="post-entry">
                                <div class="d-block text-up-small text-grey-4 margin-bottom-15px wow fadeInLeft">
                                    <p>
                                        At Packages, traditional batch digestion process for the cooking of wheat straw
                                        has been replaced by a continuous digestion process. This has not only resulted
                                        in improved pulp quality but has also helped us in recovering the chemicals from
                                        black liquor. Today, both our Unbleached and Bleached Pulps are much better in
                                        quality than was possible through batch processing and we have a Chemical
                                        Recovery Plant to recover the chemicals from black liquor.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
@endsection
